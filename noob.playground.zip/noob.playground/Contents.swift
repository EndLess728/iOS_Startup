//: Playground - noun: a place where people can play

import UIKit

var myAge : Int = 32
myAge = 33


let myName : String = "Mantu"

let mySurName : String = "Kumar"

let myAgeInTenYears = myAge + 10

let myFullName = "\(myName) \(mySurName)"

let myDetails = "\(myFullName) ,\(myAge)"



let wholeNumber : Int = 12
let text : String = "abc"

let booleans : Bool = true

let floatingPointerNumber : Float = 1.3

let double : Double = 3.1435